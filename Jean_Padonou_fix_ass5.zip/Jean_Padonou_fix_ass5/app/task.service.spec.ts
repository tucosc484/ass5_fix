/* tslint:disable:no-unused-variable */

import {TestBed, async, inject} from '@angular/core/testing';
import {Task} from './task';
import {TaskService} from './task.service';

describe('TaskService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TaskService]
    });
  });

  it('should ...', inject([TaskService], (service: TaskService) => {
    expect(service).toBeTruthy();
  }));

  describe('#getAllTasks()', () => {

    it('should return an empty array by default', inject([TaskService], (service: TaskService) => {
      expect(service.getAllTasks()).toEqual([]);
    }));

    it('should return all todos', inject([TaskService], (service: TaskService) => {
      let task1 = new Task({title: 'Hello 1', complete: false});
      let task2 = new Task({title: 'Hello 2', complete: true});
      service.addTask(task1);
      service.addTask(task2);
      expect(service.getAllTasks()).toEqual([task1, task2]);
    }));

  });

  describe('#save(task)', () => {

    it('should automatically assign an incrementing id', inject([TaskService], (service: TaskService) => {
      let task1 = new Task({title: 'Hello 1', complete: false});
      let task2 = new Task({title: 'Hello 2', complete: true});
      service.addTask(task1);
      service.addTask(task2);
      expect(service.getTaskById(1)).toEqual(task1);
      expect(service.getTaskById(2)).toEqual(task2);
    }));

  });

  describe('#deleteTaskById(id)', () => {

    it('should remove task with the corresponding id', inject([TaskService], (service: TaskService) => {
      let task1 = new Task({title: 'Hello 1', complete: false});
      let task2 = new Task({title: 'Hello 2', complete: true});
      service.addTask(task1);
      service.addTask(task2);
      expect(service.getAllTasks()).toEqual([task1, task2]);
      service.deleteTaskById(1);
      expect(service.getAllTasks()).toEqual([task2]);
      service.deleteTaskById(2);
      expect(service.getAllTasks()).toEqual([]);
    }));

    it('should not removing anything if todo with corresponding id is not found', inject([TaskService], (service: TaskService) => {
      let task1 = new Task({title: 'Hello 1', complete: false});
      let task2 = new Task({title: 'Hello 2', complete: true});
      service.addTask(task1);
      service.addTask(task2);
      expect(service.getAllTasks()).toEqual([task1, task2]);
      service.deleteTaskById(3);
      expect(service.getAllTasks()).toEqual([task1, task2]);
    }));

  });

  describe('#updateTaskById(id, values)', () => {

    it('should return task with the corresponding id and updated data', inject([TaskService], (service: TaskService) => {
      let task = new Task({title: 'Hello 1', complete: false});
      service.addTask(task);
      let updatedTask = service.updateTaskById(1, {
        title: 'new title'
      });
      expect(updatedTask.title).toEqual('new title');
    }));

    it('should return null if todo is not found', inject([TaskService], (service: TaskService) => {
      let task = new Task({title: 'Hello 1', complete: false});
      service.addTask(task);
      let updatedTask = service.updateTaskById(2, {
        title: 'new title'
      });
      expect(updatedTask).toEqual(null);
    }));

  });

  describe('#toggleTaskComplete(task)', () => {

    it('should return the updated task with inverse complete status', inject([TaskService], (service: TaskService) => {
      let task = new Task({title: 'Hello 1', complete: false});
      service.addTask(task);
      let updatedTask = service.toggleTaskComplete(task);
      expect(updatedTask.complete).toEqual(true);
      service.toggleTaskComplete(task);
      expect(updatedTask.complete).toEqual(false);
    }));

  });

});
